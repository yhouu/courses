#include "types.h"
#include "stat.h"
#include "user.h"

int main(void){
  return halt();
}
